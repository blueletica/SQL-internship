/*
Programmer: Bahati Mulishi
file name:4. Data Transformation
description: This query will use SQL functions to transform data
*/

USE SpotifyData
GO

/*
this code will handling NULL values
Replace NULL values in the 'explicit' column with 0
*/
UPDATE Music
SET explicit = COALESCE(explicit, 0);

-- Convert release_date to DATE data type
UPDATE Music
SET release_date = TRY_CAST(release_date AS DATE);

-- Check if the 'duration_minutes' column already exists
IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Music' AND COLUMN_NAME = 'duration_minutes')
BEGIN
    -- Add a new column 'duration_minutes' in minutes
    ALTER TABLE Music
    ADD duration_minutes FLOAT;

    -- Update 'duration_minutes' based on 'duration_ms'
    UPDATE Music
    SET duration_minutes = duration_ms / 60000;
END

-- this code will extract the first word from the 'name' column
SELECT id, SUBSTRING(name, 1, CHARINDEX(' ', name + ' ') - 1) AS first_word
FROM Music;

-- this code will extract the last 4 characters from the 'id' column
SELECT id, RIGHT(id, 4) AS last_four_characters
FROM Music;

-- this code will extract the first two characters from the 'release_date' column
SELECT id, SUBSTRING(release_date, 1, 2) AS first_two_characters
FROM Music;

--this code will calculate the average duration in minutes:
SELECT AVG(duration_ms / 60000.0) AS avg_duration_minutes
FROM Music;

-- this code calculate the average danceability for songs released in 1928
SELECT AVG(danceability) AS avg_danceability
FROM Music
WHERE year = 1928;

--this code count the number of explicit songs
SELECT COUNT(*) AS explicit_song_count
FROM Music
WHERE explicit = 1;

--this code will find the song with the highest acousticness
SELECT TOP 1 id, name, artists, acousticness
FROM Music
ORDER BY acousticness DESC;

-- this code calculate the total energy for songs released after the year 2000
SELECT SUM(energy) AS total_energy
FROM Music
WHERE year > 2000;

-- this code find the average valence for songs with explicit content
SELECT AVG(valence) AS avg_valence
FROM Music
WHERE explicit = 1;

-- this code will find the minimum and maximum loudness values
SELECT MIN(loudness) AS min_loudness, MAX(loudness) AS max_loudness
FROM Music;
