/*
Programmer: Bahati Mulishi 
file name: task 1 part2.2 
description: This query will check for duplicates and anomalies.
*/

USE SpotifyData;
GO

/*
the code will check for duplicates
Check for duplicate rows based on the 'id' column
*/
SELECT id, COUNT(*) AS DuplicateCount
FROM Music
GROUP BY id
HAVING COUNT(*) > 1;
GO

USE SpotifyData;

-- Check for anomalies in the 'id' column
SELECT *
FROM Music
WHERE LEN(id) = 0 OR id IS NULL;

-- Check for anomalies in the 'name' column
SELECT *
FROM Music
WHERE LEN(name) = 0 OR name IS NULL;

-- Check for anomalies in the 'artists' column
SELECT *
FROM Music
WHERE LEN(artists) = 0 OR artists IS NULL;

-- Check for anomalies in the 'duration_ms' column
SELECT *
FROM Music
WHERE duration_ms < 0;

-- Check for anomalies in the 'release_date' column
SELECT *
FROM Music
WHERE LEN(release_date) = 0 OR release_date IS NULL;

-- Check for anomalies in the 'year' column
SELECT *
FROM Music
WHERE year < 0 OR LEN(year) = 0 OR year IS NULL;

-- Check for anomalies in the 'acousticness' column
SELECT *
FROM Music
WHERE acousticness < 0 OR acousticness > 1 OR LEN(acousticness) = 0 OR acousticness IS NULL;

-- Check for anomalies in the 'danceability' column
SELECT *
FROM Music
WHERE danceability < 0 OR danceability > 1 OR LEN(danceability) = 0 OR danceability IS NULL;

-- Check for anomalies in the 'energy' column
SELECT *
FROM Music
WHERE energy < 0 OR energy > 1 OR LEN(energy) = 0 OR energy IS NULL;

-- Check for anomalies in the 'instrumentalness' column
SELECT *
FROM Music
WHERE TRY_CAST(instrumentalness AS FLOAT) < 0 OR TRY_CAST(instrumentalness AS FLOAT) > 1 OR LEN(instrumentalness) = 0 OR instrumentalness IS NULL;

-- Check for anomalies in the 'liveness' column
SELECT *
FROM Music
WHERE liveness < 0 OR liveness > 1 OR LEN(liveness) = 0 OR liveness IS NULL;

-- Check for anomalies in the 'loudness' column
SELECT *
FROM Music
WHERE LEN(loudness) = 0 OR loudness IS NULL;

-- Check for anomalies in the 'speechiness' column
SELECT *
FROM Music
WHERE speechiness < 0 OR speechiness > 1 OR LEN(speechiness) = 0 OR speechiness IS NULL;

-- Check for anomalies in the 'tempo' column
SELECT *
FROM Music
WHERE tempo < 0 OR LEN(tempo) = 0 OR tempo IS NULL;

-- Check for anomalies in the 'valence' column
SELECT *
FROM Music
WHERE valence < 0 OR valence > 1 OR LEN(valence) = 0 OR valence IS NULL;

-- Check for anomalies in the 'mode' column
SELECT *
FROM Music
WHERE mode NOT IN (0, 1) OR LEN(mode) = 0 OR mode IS NULL;

-- Check for anomalies in the 'key' column
SELECT *
FROM Music
WHERE LEN([key]) = 0 OR [key] IS NULL;

-- Check for anomalies in the 'popularity' column
SELECT *
FROM Music
WHERE popularity < 0 OR LEN(popularity) = 0 OR popularity IS NULL;

-- Check for anomalies in the 'explicit' column
SELECT *
FROM Music
WHERE explicit NOT IN (0, 1) OR LEN(explicit) = 0 OR explicit IS NULL;

