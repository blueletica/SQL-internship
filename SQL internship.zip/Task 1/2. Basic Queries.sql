/*
Programmer: Bahati Mulishi
file name: 2. Basic Queries 
description: This query will retrieve specific data subsets and aggregate information.
*/

USE SpotifyData
GO

-- this code will select all the data where the explicit is less than 1
SELECT *
FROM Music
WHERE explicit < 1;
GO

-- This code will select all the data where the year is greater than 1928 and the popularity is less than 50
SELECT *
FROM Music
WHERE year > 1928 AND popularity < 50;
GO

--this will calculates the average duration in milliseconds for all rows in the 'Music' table.
SELECT AVG(duration_ms) AS avg_duration
FROM Music;
GO

-- this code will count the number of records in the Music table
SELECT COUNT(*)
FROM Music;
GO

--this code will Find the average value of theacousticness column:
SELECT AVG(acousticness)
FROM Music;
GO

-- this code will calculate the total sum of a energy column
SELECT SUM(energy)
FROM Music;
GO

-- this code will find the maximum value in the loudness column
SELECT MAX(loudness)
FROM Music;
GO

-- this code will find the minimum value in the liveness column
SELECT MIN(liveness)
FROM Music;
GO

-- this code will retrieve distinct values from the valence column
SELECT DISTINCT valence
FROM Music;
GO

-- this code will retrieves the 'id', 'name', and 'popularity' columns for all rows in the Music table, ordered by 'popularity' in descending order
SELECT id, name, popularity
FROM Music
ORDER BY popularity DESC;
GO

--this code will retrieves the top 5 rows from the Music table. 
SELECT TOP 5 *
FROM Music;

-- this code will  find the average duration and popularity for each year
SELECT year, AVG(duration_ms) AS avg_duration, AVG(popularity) AS avg_popularity
FROM Music
GROUP BY year;