/*
Programmer: Bahati Mulishi
file name: task 1 part2.1 
description: This query will check for missing values in each column in the Music table
*/


USE SpotifyData;
GO

-- the query will check for Missing Values:

-- Check for missing values in the 'id' column
SELECT *
FROM Music
WHERE id IS NULL;

-- Check for missing values in the 'name' column
SELECT *
FROM Music
WHERE name IS NULL;

-- Check for missing values in the 'artists' column
SELECT *
FROM Music
WHERE artists IS NULL;

-- Check for missing values in the 'duration_ms' column
SELECT *
FROM Music
WHERE duration_ms IS NULL;

-- Check for missing values in the 'release_date' column
SELECT *
FROM Music
WHERE release_date IS NULL;

-- Check for missing values in the 'year' column
SELECT *
FROM Music
WHERE year IS NULL;

-- Check for missing values in the 'acousticness' column
SELECT *
FROM Music
WHERE acousticness IS NULL;

-- Check for missing values in the 'danceability' column
SELECT *
FROM Music
WHERE danceability IS NULL;

-- Check for missing values in the 'energy' column
SELECT *
FROM Music
WHERE energy IS NULL;

-- Check for missing values in the 'instrumentalness' column
SELECT *
FROM Music
WHERE instrumentalness IS NULL;

-- Check for missing values in the 'liveness' column
SELECT *
FROM Music
WHERE liveness IS NULL;

-- Check for missing values in the 'loudness' column
SELECT *
FROM Music
WHERE loudness IS NULL;

-- Check for missing values in the 'speechiness' column
SELECT *
FROM Music
WHERE speechiness IS NULL;

-- Check for missing values in the 'tempo' column
SELECT *
FROM Music
WHERE tempo IS NULL;

-- Check for missing values in the 'valence' column
SELECT *
FROM Music
WHERE valence IS NULL;

-- Check for missing values in the 'mode' column
SELECT *
FROM Music
WHERE mode IS NULL;

-- Check for missing values in the 'key' column
SELECT *
FROM Music
WHERE [key] IS NULL;

-- Check for missing values in the 'popularity' column
SELECT *
FROM Music
WHERE popularity IS NULL;

-- Check for missing values in the 'explicit' column
SELECT *
FROM Music
WHERE explicit IS NULL;