/*
Programmer: Bahati Mulishi
file name: 5. Complex Queries and Analysis
description: This query will write complex SQL queries 
*/

USE SpotifyData
GO

-- this code will find the songs with a popularity higher than the average popularity.
SELECT id, name, popularity
FROM Music
WHERE popularity > (SELECT AVG(popularity) FROM Music);


-- This code will find the artist with the highest average danceability.
SELECT TOP 1 artists, AVG(danceability) AS avg_danceability
FROM Music
GROUP BY artists
ORDER BY avg_danceability DESC;



-- This code finds the top 3 songs with the highest popularity for each year
WITH RankedSongs AS (
    SELECT id, name, popularity, year,
        RANK() OVER (PARTITION BY year ORDER BY popularity DESC) as popularity_rank
    FROM Music
)
SELECT id, name, popularity, year
FROM RankedSongs
WHERE popularity_rank <= 3;

-- this code will analyze trends based on the release year
SELECT year, COUNT(*) AS num_songs
FROM Music
GROUP BY year
ORDER BY year;

--this code will identify songs with high acousticness
SELECT *
FROM Music
WHERE acousticness > 0.8;

--this code will calculate average danceability and energy for each year
SELECT year, AVG(danceability) AS avg_danceability, AVG(energy) AS avg_energy
FROM Music
GROUP BY year
ORDER BY year;
