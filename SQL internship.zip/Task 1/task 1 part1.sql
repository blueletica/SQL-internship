/*
Programmer: Bahati Mulishi
file name: task 1 part1 
description: This query will explore the dataset's structure, identify key tables, and understand relationships between them
*/


USE SpotifyData; 
GO

--the code will list all tables in a database
SELECT TABLE_NAME
FROM information_schema.tables
WHERE table_type = 'BASE TABLE';
GO

--this code will view columns of a specific table(music)
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
FROM information_schema.columns
WHERE TABLE_NAME = 'Music';
GO

-- this code will alter the id column to not have null values
ALTER TABLE Music
ALTER COLUMN id VARCHAR(50) NOT NULL;
GO

--to make the id column the primary key
ALTER TABLE Music
ADD CONSTRAINT PK_Music PRIMARY KEY (id);
GO

--this code will find the primary key columns of a table
SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE OBJECTPROPERTY(OBJECT_ID(CONSTRAINT_SCHEMA + '.' + QUOTENAME(CONSTRAINT_NAME)), 'IsPrimaryKey') = 1
AND TABLE_NAME = 'Music';
GO

