/*
Programmer: Bahati Mulishi
file name: 3. Join Operations
description: This query will show different types of joins (INNER, LEFT, RIGHT, FULL) to combine data from multiple columns.
*/

USE SpotifyData
GO

--INNER JOIN, it will returns only the rows where there is a match in both tables
SELECT *
FROM Music AS m1
INNER JOIN Music AS m2 ON m1.id = m2.id;