/*
FileName: database SpotifyData.sql
Programmer Name: BAHATI MULISHI
Description: This file creates the database called SpotifyData
*/

USE master
GO

CREATE DATABASE SpotifyData
ON PRIMARY 
(
NAME = 'SpotifyData.data',
FILENAME = 'C:\InternProject\SpotifyData_data.mdf',
SIZE = 50MB,
FILEGROWTH = 20%
)

LOG ON 
(
NAME = 'SpotifyData.log',
FILENAME = 'C:\InternProject\SpotifyData_data.ldf',
SIZE = 50MB,
FILEGROWTH = 20%
)
GO
PRINT 'The SpotifyData databse has been created'