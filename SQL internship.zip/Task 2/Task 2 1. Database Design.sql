/*
Programmer: Bahati Mulishi
file name: Task 2     1. Database Design
description: This query will design appropriate indexing
*/

USE SpotifyData
GO

-- this index will be  filtering songs by release year
CREATE INDEX idx_Year ON Music (year);
 

--index for explicit songs
CREATE INDEX idx_Explicit ON Music (explicit);


--index for filtering songs released after 2000
CREATE INDEX idx_Year_After_2000 ON Music (year) INCLUDE (energy);


--index for sorting by acousticness
CREATE INDEX idx_Acousticness ON Music (acousticness) INCLUDE (id, name, artists);


--index for calculating average danceability in 1928
CREATE INDEX idx_Year_Danceability ON Music (year, danceability);
