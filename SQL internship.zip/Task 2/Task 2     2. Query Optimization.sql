/*
Programmer: Bahati Mulishi
file name: Task 2     2. Query Optimization
description: This query will write and optimize SQL queries
*/

USE SpotifyData
GO

--enable actual execution plan
SET STATISTICS IO, TIME ON;

/*
retrieve songs released in a specific year
use the index on 'year' for efficient retrieval
*/
-- Utilize an index seek for better performance
SELECT *
FROM Music WITH (INDEX(idx_Year))  -- Hint to use the 'idx_Year' index
WHERE year = 1928;


 
/*
retrieve songs with explicit content:
use the index on 'explicit' for efficient retrieval
*/
SELECT *
FROM Music
WHERE explicit = 1;


/*
calculate the average energy for songs released after 2000:
use the index on 'year' for efficient filtering
*/
SELECT AVG(energy) AS avg_energy
FROM Music
WHERE year > 2000;


/*
find the song with the highest acousticness:
use the index on 'acousticness' for efficient sorting
*/
SELECT TOP 1 id, name, artists, acousticness
FROM Music
ORDER BY acousticness DESC;


/*
calculate the average danceability for songs released in 1928:
use the composite index on 'year' and 'danceability' for efficient filtering
*/
SELECT AVG(danceability) AS avg_danceability
FROM Music
WHERE year = 1928;


/*
count the Number of explicit Songs:
use the index on 'explicit' for efficient counting
*/
SELECT COUNT(*) AS explicit_song_count
FROM Music
WHERE explicit = 1;


/*
find the minimum and maximum loudness values:
utilize the index on 'loudness' for efficient aggregation
*/
SELECT MIN(loudness) AS min_loudness, MAX(loudness) AS max_loudness
FROM Music;


/*
extract the first word from the 'Name' column:
utilize functions for string manipulation
*/
SELECT id, SUBSTRING(name, 1, CHARINDEX(' ', name + ' ') - 1) AS first_word
FROM Music;