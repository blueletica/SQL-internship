/*
Programmer: Bahati Mulishi
file name: Task 2     3. Indexing and Tuning
description: This query will implement indexing strategies 
*/

USE SpotifyData
GO

-- Create a clustered index on the 'id' column if it does not already exist
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_Clustered_id' AND object_id = OBJECT_ID('Music'))
BEGIN
    CREATE CLUSTERED INDEX idx_Clustered_id ON Music(id);
END

-- Add an index hint to the query that finds the song with the highest acousticness
SELECT TOP 1 id, name, artists, acousticness
FROM Music WITH(INDEX(idx_acousticness))
ORDER BY acousticness DESC;

-- Create a non-clustered index on the 'year' and 'popularity' columns if it does not already exist
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_year_popularity' AND object_id = OBJECT_ID('Music'))
BEGIN
    CREATE NONCLUSTERED INDEX idx_year_popularity ON Music(year, popularity);
END

-- Create a non-clustered index on the 'energy' column if it does not already exist
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_energy' AND object_id = OBJECT_ID('Music'))
BEGIN
    CREATE NONCLUSTERED INDEX idx_energy ON Music(energy);
END

-- Create a non-clustered index on the 'loudness' column if it does not already exist
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_loudness' AND object_id = OBJECT_ID('Music'))
BEGIN
    CREATE NONCLUSTERED INDEX idx_loudness ON Music(loudness);
END

-- Create a non-clustered index on the 'liveness' column if it does not already exist
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_liveness' AND object_id = OBJECT_ID('Music'))
BEGIN
    CREATE NONCLUSTERED INDEX idx_liveness ON Music(liveness);
END

-- Create a non-clustered index on the 'valence' column if it does not already exist
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'idx_valence' AND object_id = OBJECT_ID('Music'))
BEGIN
    CREATE NONCLUSTERED INDEX idx_valence ON Music(valence);
END
