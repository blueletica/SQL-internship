/*
Programmer: Bahati Mulishi
file name: Task 2    5. Performance Monitoring
description: This query will use SQL profiling tools to monitor database performance 
*/

USE SpotifyData
Go

--Query profiler
SELECT * FROM Music WHERE year = 1928;

/*
Monitoring slow queries
Query to get information about slow queries
*/
SELECT TOP 10
    total_elapsed_time, 
    text
FROM 
    sys.dm_exec_query_stats 
    CROSS APPLY sys.dm_exec_sql_text(sql_handle)
ORDER BY 
    total_elapsed_time DESC;
GO

/*
Locking and Blocking
Identify blocking queries
*/
SELECT
    r.session_id AS blocking_session_id,
    r.wait_type,
    r.wait_resource,
    t.text AS sql_text
FROM 
    sys.dm_exec_requests r
    CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) t
WHERE 
    r.blocking_session_id <> 0;


--Slow Queries
-- Identify slow queries
SET STATISTICS TIME ON;
GO
SELECT * FROM Music WHERE year = 1928;
SET STATISTICS TIME OFF;

-- Before optimization
SELECT * FROM Music WHERE year = 1928 AND danceability > 0.5;

-- After optimization
SELECT * FROM Music WHERE year = 1928 AND danceability > 0.5 ORDER BY id;

-- Rebuild indexes for the 'Music' table
ALTER INDEX ALL ON Music REBUILD;


-- Update statistics for the 'Music' table
UPDATE STATISTICS Music;
